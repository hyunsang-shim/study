#pragma once
#include "cCubeNode.h"
class cCubeHead :
	public cCubeNode
{
public:
	cCubeHead();
	~cCubeHead();

	virtual void Setup() override;
};

