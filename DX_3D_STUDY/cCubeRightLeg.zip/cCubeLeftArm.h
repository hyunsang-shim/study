#pragma once
#include "cCubeNode.h"
class cCubeLeftArm :
	public cCubeNode
{
public:
	cCubeLeftArm();
	~cCubeLeftArm();

	virtual void Setup() override;


};

