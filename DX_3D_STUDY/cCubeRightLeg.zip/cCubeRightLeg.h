#pragma once
#include "cCubeNode.h"
class cCubeRightLeg :
	public cCubeNode
{
public:
	cCubeRightLeg();
	~cCubeRightLeg();

	virtual void Setup() override;


};

