#pragma once
#include "cCubeNode.h"
class cCubeRightArm :
	public cCubeNode
{
public:
	cCubeRightArm();
	~cCubeRightArm();

	virtual void Setup() override;

};

