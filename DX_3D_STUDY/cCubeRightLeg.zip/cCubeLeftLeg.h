#pragma once
#include "cCubeNode.h"
class cCubeLeftLeg :
	public cCubeNode
{
public:
	cCubeLeftLeg();
	~cCubeLeftLeg();

	virtual void Setup() override;


};

