#pragma once
class cBattleScene
{
public:
	cBattleScene();
	~cBattleScene();
};

