#pragma once
#include "cManager.h"

class SceneManager : public cManager
{
public:
	SceneManager();
	~SceneManager();
};

