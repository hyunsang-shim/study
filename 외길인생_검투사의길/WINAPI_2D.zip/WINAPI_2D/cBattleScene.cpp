#include "stdafx.h"
#include "cBattleScene.h"


cBattleScene::cBattleScene()
{
}


cBattleScene::~cBattleScene()
{
}
