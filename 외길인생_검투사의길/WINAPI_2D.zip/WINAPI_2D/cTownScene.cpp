#include "stdafx.h"
#include "cTownScene.h"


cTownScene::cTownScene()
{
}


cTownScene::~cTownScene()
{
}
