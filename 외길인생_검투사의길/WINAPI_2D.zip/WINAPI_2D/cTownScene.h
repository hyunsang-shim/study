#pragma once
#include "SceneManager.h"


class cTownScene : public SceneManager
{
public:
	cTownScene();
	~cTownScene();
};

