#include "stdafx.h"
#include "cMainGame.h"


cMainGame::cMainGame()
{
}


cMainGame::~cMainGame()
{
}

void cMainGame::Setup()
{
	// set...
	// 1. draw
	// 2. Vertex
	// 3. matrix initialize
}

void cMainGame::Update()
{
	// Scale, Rotate, Transform

	// World, View, Projectiopn, Viewport
}

void cMainGame::Render(HDC)
{
	// draw... lines
	// movetoex / lineto
}

void cMainGame::WndProc(HWND hWNd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{

	}
}
